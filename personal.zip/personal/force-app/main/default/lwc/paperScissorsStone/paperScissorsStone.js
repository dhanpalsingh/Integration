import { LightningElement,track,api } from 'lwc';



export default class PaperScissorsStone extends LightningElement {

    showchoose=true;
   @api playername;
 playerSelected;
compSelected;
playerScore=0;
compScore=0;
imgUrl;
gameResult= false;
    handleClick(event)
    {
       
      this.playerSelected =event.target.label;
       
       this.showchoose=false;
       this.generateCompSelected();
    }
    generateCompSelected()
    {
        const min = 0;
const max = 2;
const num = Math.floor(Math.random() * (max - min + 1)) + min;

     

if(num==0)
{
    this.compSelected='Paper';
}
else if (num==1)
{
   this.compSelected='Scissors';

}
else{
    this.compSelected='Stone';
}
this.winnerNameLogic();

    }
    winnerNameLogic()
    {

        if(this.playerSelected=== this.compSelected)
        {
            this.winnerName='Its a draw!'
        }
       else if(this.playerSelected==='Paper' && this.compSelected==='Stone')
        {
            this.winnerName= this.playername+' '+ 'Wins!'
            this.playerScore++;
        }
       else if(this.playerSelected==='Paper' && this.compSelected==='Scissors')
        {
            this.winnerName='Computer Wins!'
            this.compScore++;
        }
       else if(this.playerSelected==='Stone' && this.compSelected==='Scissors')
        {
            this.winnerName= this.playername+' '+ 'Wins!'
            this.playerScore++;
        }
       else if(this.playerSelected==='Stone' && this.compSelected==='Paper')
        {
            this.winnerName='Computer Wins!'
            this.compScore++;
        }
        else if(this.playerSelected==='Scissors' && this.compSelected==='Paper')
        {
            this.winnerName= this.playername +' '+ 'Wins!'
            this.playerScore++;

        }
        else if(this.playerSelected==='Scissors' && this.compSelected==='Stone')
        {
            this.winnerName='Computer Wins!'
            this.compScore++;
        }

        if(this.playerScore == 5){
                this.gameResult= true;
                this.imgUrl='https://media1.tenor.com/m/m5CaMRUMswEAAAAC/congratulations-baby-girl.gif';

        }
        else if(this.compScore ==5){
            this.imgUrl='https://media1.tenor.com/m/NUC6WS9g8UoAAAAC/shrug-idk.gif';
            this.gameResult= true;

        }


    }
    playnextHandler()
    {
       this.showchoose=true;
    }

}