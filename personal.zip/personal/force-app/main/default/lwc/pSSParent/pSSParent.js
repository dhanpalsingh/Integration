import { LightningElement } from 'lwc';

export default class PSSParent extends LightningElement {
playerName;
startComputerGame=false;

    nameCapture(event)
    {

this.playerName= event.target.value;
alert(this.playerName);
    }
    startGame()
    {
        this.playerName = this.template.querySelector('lightning-input').value;     
this.startComputerGame=true;
    }

}