import { LightningElement,track } from 'lwc';

export default class ComponentPalette extends LightningElement {
    activeItemId = 'component1-0'; // Initialize active item id
    @track 
    isRendered = false;

renderedCallback()
{
    alert('in render');
    if (!this.isRendered) {
        // Execute rendering logic
        alert('in render inside');
        // Set flag to indicate rendering logic has been executed
        this.isRendered = true;
    
    const item = this.template.querySelector('[role="option"]');
    
        item.focus();
    }
        

    }
        
    


    handleKeyDown(event) {
        const items = this.template.querySelectorAll('[role="option"]');
        const totalItems = items.length;
        
        let currentIndex = Array.from(items).findIndex(item => item.id === this.activeItemId);

        switch (event.key) {
           
            case 'Tab':
               event.preventDefault();
                currentIndex = (currentIndex + 1) % totalItems;
                break;
            default:
                break;
        }

        
        this.activeItemId = items[currentIndex].id;
        items[currentIndex].focus();
        
    }
   
   
    }

