import { LightningElement } from 'lwc';
const DELAY = 300;
export default class MovieSearchLWC extends LightningElement {
    selectedType="";
    selectedSearchValue="";
    selectedPageno=1;
    searchResult=[];
    loading = false;
    delayTimeOut;
    get options() {
        return [
            { label: 'None', value: 'None' },
            { label: 'Movie', value: 'Movie' },
            { label: 'Episode', value: 'Episode' },
            { label: 'Series', value: 'Series' },
        ];
    }
    onChange(event){
        let {name, value} = event.target;
        this.loading=true;
        if(name === 'type'){
            this.selectedType=value;

        }
        else if(name === 'search'){
            this.selectedSearchValue=value;
      
        }
        else if(name === 'Pageno'){
            this.selectedPageno=value;
      
        }
        // debouncing
        clearTimeout(this.delayTimeOut);
        this.delayTimeOut = setTimeout( () => {
            this.searchMovie();
        }, DELAY)
        

    }
    // this method is responsible for the searched movie call out 
    async searchMovie(){
        // http://www.omdbapi.com/?t=Batman&apikey=4b04a2a6
        const url=`http://www.omdbapi.com/?s=${this.selectedSearchValue}&type=${this.selectedType}&page=${this.selectedPageno}&apikey=4b04a2a6`;
      const res =  await fetch(url);
      const dataResponse = await res.json();
      console.log('Movie Search Out Put '+ JSON.stringify(dataResponse));
      this.loading=false;
      if(dataResponse.Response === 'True'){
        this.searchResult = dataResponse.Search;
      }
      console.log('Movie Search Result '+ JSON.stringify(this.searchResult));
      
    }
    get displayResult(){
       return this.searchResult.length >0 ? true : false;
    }
}