import { LightningElement, track, wire } from 'lwc';
import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import UserNameFld from '@salesforce/schema/User.Name';

export default class ChatBot extends LightningElement {
    @track messages = [];
    @track searchResult;
    @track currentUserName;
    @track welcomeMsg= true;
    @track showusericon;

    @wire(getRecord, { recordId: Id, fields: [UserNameFld ]}) 
    userDetails({error, data}) {
        if (data) {
            this.currentUserName = data.fields.Name.value;
            
        } else if (error) {
            this.error = error ;
        }
    }

    handleKeyUp(event) {
        
        if (event.keyCode === 13) { // Check if 'Enter' key is pressed
            this.welcomeMsg = false;
            this.showusericon= true;
            const userInput = event.target.value;
            this.messages.push({ id: this.messages.length, text: userInput, type: 'user', iconname: "utility:user" });
            event.target.value = ''; // Clear input field

            // Simulate bot response (you can replace this with actual logic to generate bot responses)
            const botResponse = this.generateBotResponse(userInput);
            console.log('bot message:'+botResponse);
            if(botResponse){
                this.showusericon= false;
                this.messages.push({ id: this.messages.length, text: botResponse, type: 'bot', iconname: "utility:sparkles"});

            }
            
        }
    }

    generateBotResponse(userInput) {
        // Replace this with your actual chatbot logic (e.g., API calls, conditional responses)
        // Here's a simple example responding to a user's input
        // debouncing
        var finalresult  = this.getResponse(userInput);
        finalresult.then((value) => {
            console.log('2nd output' +value);
            this.messages.push({ id: this.messages.length, text: value, type: 'bot' ,iconname: "utility:sparkles"});
            //return value;
            // Expected output: 123
          });
        
        if(finalresult){
            //console.log('Test Output:'+finalresult);

            // return finalresult;
        }
        
        // clearTimeout(this.delayTimeOut);
        // this.delayTimeOut = setTimeout( () => {
        //     this.getResponse();
        // }, DELAY)
         // calling the bard AI for the Tesxt Search 
        // code starts for callout 
        
        

        // code end for call out 




        // if (userInput.toLowerCase().includes('hello')) {
        //     return 'Hello How are you!';
        // } 
        // else if(userInput.toLowerCase().includes('how much i am loving bubbly')) {
        // return 'you love more than she thinks!';
        //     }else {
        //     return 'I did not understand that. Please try again.';
        // }
    }
    async getResponse(userInput){
        
        console.log('Inside get Response');
        // http://www.omdbapi.com/?t=Batman&apikey=4b04a2a6
      const url=`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyC4SgiM-OXAtW0UjbepH3GBLHV-ShNOF_E`;
      const requestbody = `{"contents":[{"parts":[{"text":"${userInput}"}]}]}`;
      const POST_METHOD = 'POST'; //POST method
      const CONTENT_TYPE = 'application/json';
      const responsebody = await fetch(url, {
        method: POST_METHOD,
        headers: {
            'Content-Type': CONTENT_TYPE,
        },
        body:requestbody ,
    }).then((response) => response.json());
    
    console.log('responsebody:::'+JSON.stringify(responsebody));
    console.log('User Answer:'+ responsebody.candidates[0].content.parts[0].text);
    var finalresult = responsebody.candidates[0].content.parts[0].text;

    return finalresult;
       
      //const dataResponse = await res.json();
      //console.log('Google AI Result :'+ JSON.stringify(dataResponse));
      //this.loading=false;
    //   if(dataResponse.Response === 'True'){
    //     //this.searchResult = dataResponse.Search;
    //   }
      //console.log('Google AI res 2: '+ JSON.stringify(this.searchResult));
      
    }
}