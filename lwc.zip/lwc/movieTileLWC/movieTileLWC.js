import { LightningElement ,api} from 'lwc';

export default class MovieTileLWC extends LightningElement {
 @api movie;

}